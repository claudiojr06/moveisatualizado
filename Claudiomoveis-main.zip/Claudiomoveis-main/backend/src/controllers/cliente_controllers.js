import * as clienteService from '../services/clienteService.js'

export async function listar (req,res) {
    
const cliente = await clienteService.listarcliente()
    
    return res.status(200).json(cliente)

}

export async function buscarid (req,res) {
const cliente = await clienteService.buscarcPorId(req.params.id)
   if(!cliente){
    return res.status(404).json({Message: 'Cliente não encontrado!'} )
}
    return res.status(200).json(cliente)
}

export async function cadastrar (req,res)  {
        

    const novoCliente = await clienteService.cadastrarcliente(req.body, res)
        
}


export async function remover(req, res) {
        const clienteRemovido = await clienteService.removercliente(req.params.id)
        if (!clienteRemovido) {
            return res.status(404).json({ Message: 'Cliente não Encontrado!' })
        }
        return res.status(200).json(clienteRemovido)
        
}

export async function atualizar(req, res) {
    const clienteatual = await clienteService.atualizarcliente(req.params.id, req.body)
    if(!clienteatual) {
        return res.status(404).json({Message: 'Cliente não encontrado!'})

    }
    return res.status(200).json(clienteatual)

    
}
