import express from 'express'
import cliente_routes from './routes/cliente_routes.js'
import produto_routes from './routes/produto_routes.js'
import sequelize from './config/database.js'

const app = express();
app.use(express.json())

app.use('/cliente', cliente_routes)
app.use('/produto', produto_routes)

try {
  await sequelize.authenticate()
  await sequelize.sync()
   app.listen(3000, () => console.log('Servidor iniciado.'))
} catch (erro) {
  console.error('Falha ao Iniciar:', erro)
  process.exit(1)
}
